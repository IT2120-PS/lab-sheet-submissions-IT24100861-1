setwd("C:\\Users\\aaa\\OneDrive\\Desktop\\IT__24100861")
    #(01)
# Uniform distribution between 0 and 40 minutes
a <- 0
b <- 40
# Probability between 10 and 25 minutes
p <- punif(25, min = a, max = b) - punif(10, min = a, max = b)
p

    #(02)
lambda <- 1/3
# Probability at most 2 hours
p <- pexp(2, rate = lambda)
p

    #(03) i
mean <- 100
sd <- 15

p <- 1 - pnorm(130, mean = mean, sd = sd)
p

    #(03)ii
q <- qnorm(0.95, mean = mean, sd = sd)
q




